/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type CategoryId = 'history' | 'science' | 'sports' | 'geography' | 'current_affairs';

export interface CategoryInfo {
  id: CategoryId;
  nameHindi: string;
  nameEnglish: string;
  icon: string;
  description: string;
  color: string;
  gradient: string;
  totalQuestions: number;
}

export interface Question {
  id: string;
  question: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  category: CategoryId;
  explanation: string;
  difficulty?: 'सरल' | 'मध्यम' | 'कठिन';
  isDailyFeatured?: boolean;
}

export interface QuizAnswer {
  questionId: string;
  selectedOptionIndex: number | null;
  isCorrect: boolean;
  timeSpentSec: number;
}

export interface QuizSessionResult {
  id: string;
  date: string;
  categoryTitle: string;
  categoryId: CategoryId | 'daily';
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  totalScore: number; // 10 points per correct answer
  maxScore: number;
  percentage: number;
  timeTakenSec: number;
  answers: QuizAnswer[];
}

export interface UserBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  unlocked: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  emailOrPhone: string;
  avatar: string;
  state: string;
  targetExam: string;
  totalPoints: number;
  quizzesPlayed: number;
  totalCorrect: number;
  totalQuestionsAttempted: number;
  currentStreakDays: number;
  lastPlayedDate: string;
  badges: UserBadge[];
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  isLoggedIn: boolean;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  state: string;
  score: number;
  accuracy: number;
  streak: number;
  rank: number;
  isCurrentUser?: boolean;
}

export interface AdMobStats {
  impressions: number;
  clicks: number;
  estimatedEarningsINR: number;
  bannerImpressions: number;
  interstitialViews: number;
  rewardedViews: number;
  eCPM: number;
}
