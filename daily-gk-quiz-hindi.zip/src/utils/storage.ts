/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Question, UserProfile, QuizSessionResult, LeaderboardEntry, AdMobStats, UserBadge } from '../types';
import { INITIAL_QUESTIONS } from '../data/initialQuestions';

const STORAGE_KEYS = {
  QUESTIONS: 'daily_gk_questions_v1',
  USER_PROFILE: 'daily_gk_user_profile_v1',
  QUIZ_HISTORY: 'daily_gk_history_v1',
  LEADERBOARD: 'daily_gk_leaderboard_v1',
  ADMOB_STATS: 'daily_gk_admob_stats_v1',
  ADMIN_PIN: 'daily_gk_admin_pin_v1',
};

const DEFAULT_BADGES: UserBadge[] = [
  { id: 'first_quiz', title: 'प्रारंभिक विजेता', description: 'पहला दैनिक क्विज पूरा किया', icon: 'Sparkles', unlocked: false },
  { id: 'century', title: 'शतकवीर', description: 'कुल 100+ अंक अर्जित किए', icon: 'Award', unlocked: false },
  { id: 'streak_3', title: 'नियमित अभ्यासी', description: 'लगातार 3 दिन क्विज खेला', icon: 'Flame', unlocked: false },
  { id: 'history_buff', title: 'इतिहास मर्मज्ञ', description: 'इतिहास क्विज में 100% अंक पाए', icon: 'Landmark', unlocked: false },
  { id: 'science_wiz', title: 'विज्ञान रत्न', description: 'विज्ञान क्विज में उत्कृष्ट प्रदर्शन', icon: 'Atom', unlocked: false },
  { id: 'gk_samrat', title: 'GK सम्राट', description: 'कुल 500+ अंक और 80%+ सटीकता', icon: 'Crown', unlocked: false },
];

export const DEFAULT_USER: UserProfile = {
  id: 'user_default',
  name: 'अभ्यर्थी विद्यार्थी',
  emailOrPhone: 'student@gkquiz.in',
  avatar: '👨‍🎓',
  state: 'उत्तर प्रदेश',
  targetExam: 'UPSC / SSC / State PCS',
  totalPoints: 0,
  quizzesPlayed: 0,
  totalCorrect: 0,
  totalQuestionsAttempted: 0,
  currentStreakDays: 1,
  lastPlayedDate: '',
  badges: DEFAULT_BADGES,
  soundEnabled: true,
  vibrationEnabled: true,
  isLoggedIn: true,
};

const SEED_LEADERBOARD: LeaderboardEntry[] = [
  { id: 'lb_1', name: 'अमित कुमार कुशवाहा', avatar: '👨‍💼', state: 'बिहार', score: 380, accuracy: 95, streak: 8, rank: 1 },
  { id: 'lb_2', name: 'प्रिया शर्मा', avatar: '👩‍🎓', state: 'राजस्थान', score: 350, accuracy: 92, streak: 7, rank: 2 },
  { id: 'lb_3', name: 'विक्रम राठौड़', avatar: '👨‍🏫', state: 'मध्य प्रदेश', score: 330, accuracy: 89, streak: 6, rank: 3 },
  { id: 'lb_4', name: 'अंजलि वर्मा', avatar: '👩‍💼', state: 'उत्तर प्रदेश', score: 290, accuracy: 87, streak: 5, rank: 4 },
  { id: 'lb_5', name: 'रोहन मेहरा', avatar: '🧑‍💻', state: 'दिल्ली', score: 260, accuracy: 84, streak: 4, rank: 5 },
  { id: 'lb_6', name: 'कविता पटेल', avatar: '👩‍🏫', state: 'गुजरात', score: 240, accuracy: 81, streak: 3, rank: 6 },
  { id: 'lb_7', name: 'संदीप यादव', avatar: '👨‍🎓', state: 'हरियाणा', score: 210, accuracy: 80, streak: 3, rank: 7 },
  { id: 'lb_8', name: 'दीक्षा मिश्रा', avatar: '👩‍🎓', state: 'उत्तराखंड', score: 190, accuracy: 78, streak: 2, rank: 8 },
];

const DEFAULT_ADMOB: AdMobStats = {
  impressions: 48,
  clicks: 3,
  estimatedEarningsINR: 84.50,
  bannerImpressions: 32,
  interstitialViews: 12,
  rewardedViews: 4,
  eCPM: 176.0,
};

export const getStoredQuestions = (): Question[] => {
  if (typeof window === 'undefined') return INITIAL_QUESTIONS;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.QUESTIONS);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(INITIAL_QUESTIONS));
      return INITIAL_QUESTIONS;
    }
    return JSON.parse(data);
  } catch {
    return INITIAL_QUESTIONS;
  }
};

export const saveQuestions = (questions: Question[]): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.QUESTIONS, JSON.stringify(questions));
  } catch (e) {
    console.error('Failed to save questions:', e);
  }
};

export const resetQuestionsToDefault = (): Question[] => {
  saveQuestions(INITIAL_QUESTIONS);
  return INITIAL_QUESTIONS;
};

export const getStoredUserProfile = (): UserProfile => {
  if (typeof window === 'undefined') return DEFAULT_USER;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(DEFAULT_USER));
      return DEFAULT_USER;
    }
    return JSON.parse(data);
  } catch {
    return DEFAULT_USER;
  }
};

export const saveUserProfile = (profile: UserProfile): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  } catch (e) {
    console.error('Failed to save profile:', e);
  }
};

export const getStoredQuizHistory = (): QuizSessionResult[] => {
  if (typeof window === 'undefined') return [];
  try {
    const data = localStorage.getItem(STORAGE_KEYS.QUIZ_HISTORY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

export const saveQuizSessionResult = (result: QuizSessionResult): void => {
  if (typeof window === 'undefined') return;
  try {
    const history = getStoredQuizHistory();
    history.unshift(result);
    localStorage.setItem(STORAGE_KEYS.QUIZ_HISTORY, JSON.stringify(history.slice(0, 30)));

    // Update user stats
    const profile = getStoredUserProfile();
    profile.quizzesPlayed += 1;
    profile.totalPoints += result.totalScore;
    profile.totalCorrect += result.correctCount;
    profile.totalQuestionsAttempted += result.totalQuestions;

    // Check streak
    const today = new Date().toISOString().split('T')[0];
    if (profile.lastPlayedDate !== today) {
      // If played yesterday or first time
      profile.currentStreakDays = (profile.currentStreakDays || 0) + 1;
      profile.lastPlayedDate = today;
    }

    // Unlock badges dynamically
    profile.badges.forEach((b) => {
      if (b.id === 'first_quiz' && profile.quizzesPlayed >= 1) b.unlocked = true;
      if (b.id === 'century' && profile.totalPoints >= 100) b.unlocked = true;
      if (b.id === 'streak_3' && profile.currentStreakDays >= 3) b.unlocked = true;
      if (b.id === 'history_buff' && result.categoryId === 'history' && result.correctCount === result.totalQuestions) b.unlocked = true;
      if (b.id === 'science_wiz' && result.categoryId === 'science' && result.correctCount >= 8) b.unlocked = true;
      if (b.id === 'gk_samrat' && profile.totalPoints >= 500 && (profile.totalCorrect / Math.max(1, profile.totalQuestionsAttempted)) >= 0.8) b.unlocked = true;
    });

    saveUserProfile(profile);

    // Update user on leaderboard
    updateLeaderboardWithUser(profile);
  } catch (e) {
    console.error('Failed to save quiz result:', e);
  }
};

export const getStoredLeaderboard = (): LeaderboardEntry[] => {
  if (typeof window === 'undefined') return SEED_LEADERBOARD;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.LEADERBOARD);
    if (!data) {
      localStorage.setItem(STORAGE_KEYS.LEADERBOARD, JSON.stringify(SEED_LEADERBOARD));
      return SEED_LEADERBOARD;
    }
    return JSON.parse(data);
  } catch {
    return SEED_LEADERBOARD;
  }
};

export const updateLeaderboardWithUser = (user: UserProfile) => {
  try {
    const list = getStoredLeaderboard().filter((e) => !e.isCurrentUser && e.id !== user.id);
    const accuracy = user.totalQuestionsAttempted > 0
      ? Math.round((user.totalCorrect / user.totalQuestionsAttempted) * 100)
      : 0;

    const userEntry: LeaderboardEntry = {
      id: user.id,
      name: `${user.name} (आप)`,
      avatar: user.avatar,
      state: user.state,
      score: user.totalPoints,
      accuracy,
      streak: user.currentStreakDays,
      rank: 1,
      isCurrentUser: true,
    };

    list.push(userEntry);
    list.sort((a, b) => b.score - a.score || b.accuracy - a.accuracy);

    // re-rank
    const ranked = list.map((item, idx) => ({ ...item, rank: idx + 1 }));
    localStorage.setItem(STORAGE_KEYS.LEADERBOARD, JSON.stringify(ranked));
  } catch {
    // Ignore
  }
};

export const getStoredAdMobStats = (): AdMobStats => {
  if (typeof window === 'undefined') return DEFAULT_ADMOB;
  try {
    const data = localStorage.getItem(STORAGE_KEYS.ADMOB_STATS);
    return data ? JSON.parse(data) : DEFAULT_ADMOB;
  } catch {
    return DEFAULT_ADMOB;
  }
};

export const trackAdMobImpression = (type: 'banner' | 'interstitial' | 'rewarded') => {
  if (typeof window === 'undefined') return;
  try {
    const stats = getStoredAdMobStats();
    stats.impressions += 1;
    if (type === 'banner') {
      stats.bannerImpressions += 1;
      stats.estimatedEarningsINR += 0.35;
    } else if (type === 'interstitial') {
      stats.interstitialViews += 1;
      stats.estimatedEarningsINR += 1.80;
    } else if (type === 'rewarded') {
      stats.rewardedViews += 1;
      stats.estimatedEarningsINR += 3.50;
    }
    stats.eCPM = Math.round((stats.estimatedEarningsINR / Math.max(1, stats.impressions)) * 1000 * 10) / 10;
    localStorage.setItem(STORAGE_KEYS.ADMOB_STATS, JSON.stringify(stats));
  } catch {
    // Ignore
  }
};

export const getAdminPin = (): string => {
  if (typeof window === 'undefined') return '1234';
  return localStorage.getItem(STORAGE_KEYS.ADMIN_PIN) || '1234';
};

export const setAdminPin = (pin: string): void => {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEYS.ADMIN_PIN, pin);
};
