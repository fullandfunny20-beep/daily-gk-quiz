/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Trophy, CheckCircle, XCircle, Clock, Share2, RotateCcw, Home, Award, ChevronDown, ChevronUp } from 'lucide-react';
import { QuizSessionResult, Question } from '../types';
import { soundFX } from '../utils/audio';

interface QuizResultScreenProps {
  result: QuizSessionResult;
  questions: Question[];
  onPlayAgain: () => void;
  onGoHome: () => void;
  onGoLeaderboard: () => void;
}

export const QuizResultScreen: React.FC<QuizResultScreenProps> = ({
  result,
  questions,
  onPlayAgain,
  onGoHome,
  onGoLeaderboard,
}) => {
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);
  const [copiedShare, setCopiedShare] = useState(false);

  const optionLabels = ['(क)', '(ख)', '(ग)', '(घ)'];

  const getPerformanceBadge = (percent: number) => {
    if (percent >= 90) return { title: 'उत्कृष्ट! GK सम्राट', color: 'text-amber-400', bg: 'bg-amber-500/20 border-amber-500/40', note: 'अद्भुत प्रदर्शन! आपकी सामान्य ज्ञान की तैयारी शीर्ष स्तर पर है।' };
    if (percent >= 70) return { title: 'शानदार प्रदर्शन!', color: 'text-emerald-400', bg: 'bg-emerald-500/20 border-emerald-500/40', note: 'बहुत अच्छा! आप प्रतियोगिता में बहुत आगे हैं।' };
    if (percent >= 50) return { title: 'सराहनीय प्रयास', color: 'text-blue-400', bg: 'bg-blue-500/20 border-blue-500/40', note: 'अच्छा प्रयास! थोड़ी और मेहनत से आप शीर्ष पर होंगे।' };
    return { title: 'अभ्यास जारी रखें', color: 'text-rose-400', bg: 'bg-rose-500/20 border-rose-500/40', note: 'दैनिक 10 प्रश्नों का नियमित अभ्यास आपका ज्ञान कई गुना बढ़ाएगा।' };
  };

  const badge = getPerformanceBadge(result.percentage);

  const handleShare = async () => {
    const text = `🏆 दैनिक GK क्विज - हिंदी में मेरा स्कोर!\n🎯 स्कोर: ${result.totalScore} / ${result.maxScore} अंक (${result.percentage}%)\n✅ सही उत्तर: ${result.correctCount}/${result.totalQuestions}\n📚 श्रेणी: ${result.categoryTitle}\nआप भी खेलें और सामान्य ज्ञान बढ़ाएं! 🇮🇳`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Daily GK Quiz – Hindi Score',
          text,
        });
        return;
      } catch {
        // Fallback to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(text);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 3000);
    } catch {
      // Ignore
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-900 text-slate-100 overflow-y-auto">
      {/* Top Banner */}
      <div className="bg-gradient-to-b from-slate-950 via-slate-900 to-slate-900 p-6 flex flex-col items-center text-center border-b border-slate-800">
        <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center shadow-xl shadow-orange-500/20 mb-3 text-4xl animate-in zoom-in-75 duration-300">
          🏆
        </div>

        <div className={`px-3 py-1 rounded-full text-xs font-bold border mb-2 ${badge.bg} ${badge.color}`}>
          {badge.title}
        </div>

        <h1 className="text-2xl font-extrabold text-white mb-1">
          क्विज संपूर्ण परिणाम
        </h1>
        <p className="text-xs text-slate-400 max-w-xs">
          {badge.note}
        </p>

        {/* Big Score Card */}
        <div className="w-full max-w-sm mt-5 bg-slate-800/90 rounded-2xl p-4 border border-slate-700/80 shadow-lg">
          <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
            कुल अर्जित अंक (+10 प्रति सही उत्तर)
          </div>
          <div className="text-4xl font-extrabold text-amber-400 font-mono my-1">
            {result.totalScore} <span className="text-lg text-slate-400 font-sans">/ {result.maxScore} अंक</span>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-slate-700/60 text-center">
            <div className="bg-slate-900/60 p-2 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>सही</span>
              </div>
              <div className="text-base font-bold text-emerald-300 font-mono">{result.correctCount}</div>
            </div>

            <div className="bg-slate-900/60 p-2 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-[11px] text-rose-400">
                <XCircle className="w-3.5 h-3.5" />
                <span>गलत</span>
              </div>
              <div className="text-base font-bold text-rose-300 font-mono">{result.wrongCount}</div>
            </div>

            <div className="bg-slate-900/60 p-2 rounded-lg">
              <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                <span>समय</span>
              </div>
              <div className="text-base font-bold text-slate-200 font-mono">{result.timeTakenSec}s</div>
            </div>
          </div>
        </div>

        {/* Action Buttons Grid */}
        <div className="grid grid-cols-2 gap-2.5 w-full max-w-sm mt-4">
          <button
            onClick={() => {
              soundFX.playTap();
              onPlayAgain();
            }}
            className="py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5 active:scale-95"
          >
            <RotateCcw className="w-4 h-4" />
            <span>पुनः खेलें</span>
          </button>

          <button
            onClick={handleShare}
            className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs rounded-xl border border-slate-700 transition-colors flex items-center justify-center gap-1.5 active:scale-95"
          >
            <Share2 className="w-4 h-4 text-amber-400" />
            <span>{copiedShare ? 'कॉपी हो गया!' : 'स्कोर साझा करें'}</span>
          </button>
        </div>

        <div className="flex gap-2 w-full max-w-sm mt-2">
          <button
            onClick={() => {
              soundFX.playTap();
              onGoLeaderboard();
            }}
            className="flex-1 py-2 px-3 bg-slate-800/80 hover:bg-slate-700 text-amber-300 text-xs font-semibold rounded-xl border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
          >
            <Award className="w-4 h-4" />
            <span>लीडरबोर्ड देखें</span>
          </button>

          <button
            onClick={() => {
              soundFX.playTap();
              onGoHome();
            }}
            className="flex-1 py-2 px-3 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
          >
            <Home className="w-4 h-4" />
            <span>होम स्क्रीन</span>
          </button>
        </div>
      </div>

      {/* Questions Detailed Review Section */}
      <div className="p-4 max-w-lg mx-auto w-full flex-1">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-slate-200">
            प्रश्नों की समीक्षा एवं संपूर्ण व्याख्या ({questions.length} प्रश्न)
          </h2>
          <span className="text-[11px] text-slate-400">
            टैप करके व्याख्या देखें
          </span>
        </div>

        <div className="space-y-3">
          {questions.map((q, idx) => {
            const userAns = result.answers.find((a) => a.questionId === q.id);
            const isCorrect = userAns?.isCorrect;
            const isExpanded = expandedQuestion === idx;

            return (
              <div
                key={q.id}
                className="bg-slate-800/80 rounded-xl border border-slate-700/80 overflow-hidden shadow-sm transition-all"
              >
                <button
                  onClick={() => setExpandedQuestion(isExpanded ? null : idx)}
                  className="w-full p-3.5 flex items-start justify-between gap-3 text-left hover:bg-slate-800 transition-colors"
                >
                  <div className="flex items-start gap-2.5">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                        isCorrect
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <div>
                      <h3 className="text-xs font-semibold text-slate-200 leading-snug">
                        {q.question}
                      </h3>
                      <div className="flex items-center gap-2 mt-1 text-[11px]">
                        <span className={isCorrect ? 'text-emerald-400 font-medium' : 'text-rose-400 font-medium'}>
                          {isCorrect ? 'सही उत्तर (+10 अंक)' : 'गलत उत्तर (0 अंक)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="p-1 text-slate-400 shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-3.5 pb-3.5 pt-1 border-t border-slate-700/60 bg-slate-900/50 text-xs space-y-2">
                    {/* All options */}
                    <div className="space-y-1 my-2">
                      {q.options.map((opt, oIdx) => {
                        const isCorrectOpt = oIdx === q.correctIndex;
                        const isUserChoice = userAns?.selectedOptionIndex === oIdx;

                        let optClass = 'text-slate-400 bg-slate-900/60';
                        if (isCorrectOpt) optClass = 'text-emerald-300 bg-emerald-950/70 border border-emerald-600/40 font-semibold';
                        else if (isUserChoice) optClass = 'text-rose-300 bg-rose-950/70 border border-rose-600/40 line-through';

                        return (
                          <div
                            key={oIdx}
                            className={`p-2 rounded-lg text-xs flex items-center justify-between ${optClass}`}
                          >
                            <span>
                              <span className="font-bold mr-1.5">{optionLabels[oIdx]}</span>
                              {opt}
                            </span>
                            {isCorrectOpt && <span className="text-[10px] text-emerald-400 font-bold ml-2">✓ सही उत्तर</span>}
                            {isUserChoice && !isCorrectOpt && <span className="text-[10px] text-rose-400 font-bold ml-2">✕ आपका चयन</span>}
                          </div>
                        );
                      })}
                    </div>

                    {/* Explanation */}
                    <div className="p-2.5 bg-slate-800 rounded-lg border border-amber-500/20 text-slate-300 leading-relaxed text-[11px]">
                      <span className="font-bold text-amber-300 block mb-0.5">व्याख्या:</span>
                      {q.explanation}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
