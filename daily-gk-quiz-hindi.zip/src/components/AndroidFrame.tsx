/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Smartphone, Monitor } from 'lucide-react';
import { AndroidStatusBar } from './AndroidStatusBar';

interface AndroidFrameProps {
  isPhoneFrame: boolean;
  onToggleFrame: () => void;
  children: React.ReactNode;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({
  isPhoneFrame,
  onToggleFrame,
  children,
}) => {
  return (
    <div className="w-full min-h-screen bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden font-sans">
      {/* View Mode Switcher floating pill on top right */}
      <div className="fixed top-2 right-2 z-50 flex items-center gap-1 bg-slate-900/90 backdrop-blur-md px-2.5 py-1 rounded-full border border-slate-700/80 shadow-lg text-xs">
        <button
          onClick={onToggleFrame}
          className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full transition-colors text-[11px] font-semibold ${
            isPhoneFrame ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
          title="Android मोबाइल फ्रेम दृश्य"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">मोबाइल व्यू</span>
        </button>

        <button
          onClick={onToggleFrame}
          className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full transition-colors text-[11px] font-semibold ${
            !isPhoneFrame ? 'bg-amber-500 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
          title="फुल-स्क्रीन डेस्कटॉप/टैबलेट दृश्य"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">फुल स्क्रीन</span>
        </button>
      </div>

      {isPhoneFrame ? (
        /* Android Smartphone Chassis */
        <div className="relative my-3 sm:my-6 w-full max-w-[420px] h-[92vh] max-h-[880px] bg-slate-900 rounded-[40px] border-[10px] border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col ring-1 ring-slate-700">
          {/* Status Bar */}
          <AndroidStatusBar />

          {/* Screen Content */}
          <div className="flex-1 flex flex-col overflow-hidden relative">
            {children}
          </div>

          {/* Android Home indicator bar at bottom */}
          <div className="w-full h-3 bg-slate-950 flex items-center justify-center pb-1 shrink-0 z-30">
            <div className="w-32 h-1 bg-slate-600 rounded-full" />
          </div>
        </div>
      ) : (
        /* Full-Screen Responsive View */
        <div className="w-full min-h-screen flex flex-col bg-slate-900 max-w-4xl mx-auto shadow-2xl relative border-x border-slate-800">
          <AndroidStatusBar />
          <div className="flex-1 flex flex-col overflow-hidden relative">
            {children}
          </div>
        </div>
      )}
    </div>
  );
};
