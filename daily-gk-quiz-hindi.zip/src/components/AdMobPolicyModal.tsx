/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { X, ShieldAlert, DollarSign, BarChart3, CheckCircle, Info } from 'lucide-react';
import { getStoredAdMobStats } from '../utils/storage';
import { AdMobStats } from '../types';

interface AdMobPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdMobPolicyModal: React.FC<AdMobPolicyModalProps> = ({ isOpen, onClose }) => {
  const [stats, setStats] = useState<AdMobStats | null>(null);

  useEffect(() => {
    if (isOpen) {
      setStats(getStoredAdMobStats());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl text-slate-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <DollarSign className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-white">
                Google AdMob मोनेटाइजेशन एवं नीति केंद्र
              </h2>
              <p className="text-[11px] text-slate-400">
                Google Play Store एवं AdMob वैध विज्ञापन नीतियां
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs">
          {/* Developer Revenue Summary */}
          {stats && (
            <div className="bg-slate-800/80 rounded-xl p-4 border border-slate-700">
              <div className="flex items-center justify-between mb-3">
                <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                  <BarChart3 className="w-4 h-4 text-amber-400" />
                  ऐप ओनर अनुमानित विज्ञापन राजस्व (Estimated Revenue)
                </span>
                <span className="text-[10px] text-emerald-400 font-medium bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  सक्रिय (Active)
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2.5 text-center">
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400">कुल इम्प्रेशन्स</div>
                  <div className="text-base font-bold text-white font-mono mt-0.5">
                    {stats.impressions}
                  </div>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400">अनुमानित आय</div>
                  <div className="text-base font-bold text-amber-400 font-mono mt-0.5">
                    ₹{stats.estimatedEarningsINR.toFixed(2)}
                  </div>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="text-[10px] text-slate-400">औसत eCPM</div>
                  <div className="text-base font-bold text-emerald-400 font-mono mt-0.5">
                    ₹{stats.eCPM}
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
                <span>बैनर: {stats.bannerImpressions}</span>
                <span>इंटरस्टीशियल: {stats.interstitialViews}</span>
                <span>रिवॉर्डेड वीडियो: {stats.rewardedViews}</span>
              </div>
            </div>
          )}

          {/* Strict Policy Statement */}
          <div className="bg-amber-950/40 border border-amber-600/40 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center gap-2 text-amber-300 font-bold">
              <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
              <span>महत्वपूर्ण नीति अनुपालन (Mandatory Policy Compliance)</span>
            </div>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              <strong>गूगल प्ले स्टोर और AdMob की सख्त नीति:</strong> उपयोगकर्ताओं को विज्ञापन देखने या क्लिक करने के बदले पैसे या नकद पुरस्कार का झूठा वादा नहीं किया जा सकता। यह ऐप वैध शैक्षिक ऐप है जहाँ डेवलपर विज्ञापनों से न्यायसंगत आय अर्जित करता है ताकि उपयोगकर्ताओं को सभी प्रश्न एवं सुविधाएं निःशुल्क मिल सकें।
            </p>
          </div>

          {/* AdMob Configuration Table */}
          <div className="bg-slate-800/50 rounded-xl p-3.5 border border-slate-700/80">
            <h4 className="font-semibold text-slate-200 mb-2 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-blue-400" />
              AdMob टेस्ट यूनिट आईडी (Production Integration Ready)
            </h4>
            <div className="space-y-1.5 font-mono text-[10px]">
              <div className="p-2 bg-slate-900/90 rounded border border-slate-800 flex justify-between">
                <span className="text-slate-400">App ID:</span>
                <span className="text-amber-300">ca-app-pub-3940256099942544~3347511713</span>
              </div>
              <div className="p-2 bg-slate-900/90 rounded border border-slate-800 flex justify-between">
                <span className="text-slate-400">Adaptive Banner:</span>
                <span className="text-slate-200">ca-app-pub-3940256099942544/6300978111</span>
              </div>
              <div className="p-2 bg-slate-900/90 rounded border border-slate-800 flex justify-between">
                <span className="text-slate-400">Interstitial:</span>
                <span className="text-slate-200">ca-app-pub-3940256099942544/1033173712</span>
              </div>
              <div className="p-2 bg-slate-900/90 rounded border border-slate-800 flex justify-between">
                <span className="text-slate-400">Rewarded Video:</span>
                <span className="text-slate-200">ca-app-pub-3940256099942544/5224354917</span>
              </div>
            </div>
          </div>

          {/* Checklist */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-slate-300">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>अमान्य क्लिक (Invalid Traffic) से सुरक्षित आर्किटेक्चर</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>परिवार नीति (Google Play Families Policy) के अनुसार सुरक्षित सामग्री</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>स्पष्ट 'Ad' लेबलिंग और 5-सेकंड इंटरस्टीशियल स्किप टाइमर</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors"
          >
            समझ गए (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
