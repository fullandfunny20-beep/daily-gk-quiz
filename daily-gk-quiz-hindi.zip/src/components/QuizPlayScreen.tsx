/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, CheckCircle2, XCircle, HelpCircle, ChevronRight, Volume2, VolumeX, Sparkles, AlertCircle } from 'lucide-react';
import { Question, QuizSessionResult, QuizAnswer, CategoryId } from '../types';
import { soundFX, triggerHaptic } from '../utils/audio';

interface QuizPlayScreenProps {
  questions: Question[];
  categoryTitle: string;
  categoryId: CategoryId | 'daily';
  soundEnabled: boolean;
  onToggleSound: () => void;
  onExit: () => void;
  onFinishQuiz: (result: QuizSessionResult) => void;
  onRequestRewardedAd: (type: '50_50_lifeline') => void;
}

export const QuizPlayScreen: React.FC<QuizPlayScreenProps> = ({
  questions,
  categoryTitle,
  categoryId,
  soundEnabled,
  onToggleSound,
  onExit,
  onFinishQuiz,
  onRequestRewardedAd,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [answers, setAnswers] = useState<QuizAnswer[]>([]);
  const [totalScore, setTotalScore] = useState(0);
  const [hiddenOptions, setHiddenOptions] = useState<number[]>([]);
  const [hasUsed5050, setHasUsed5050] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(30);
  const [timerActive, setTimerActive] = useState(true);
  const [startTime] = useState(Date.now());

  const currentQ = questions[currentIndex];
  const optionLabels = ['(क)', '(ख)', '(ग)', '(घ)'];

  // Timer countdown
  useEffect(() => {
    if (!timerActive || isAnswered) return;

    if (timerSeconds <= 0) {
      // Time up: auto submit as skipped/unanswered
      handleSelectOption(-1);
      return;
    }

    const timer = setInterval(() => {
      setTimerSeconds((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timerSeconds, timerActive, isAnswered]);

  // Reset per question
  useEffect(() => {
    setSelectedOption(null);
    setIsAnswered(false);
    setHiddenOptions([]);
    setShowExplanation(false);
    setTimerSeconds(30);
  }, [currentIndex]);

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;

    const isCorrect = idx === currentQ.correctIndex;
    setSelectedOption(idx);
    setIsAnswered(true);
    setShowExplanation(true);

    if (isCorrect) {
      soundFX.playCorrect();
      triggerHaptic([30, 40]);
      setTotalScore((prev) => prev + 10);
    } else {
      soundFX.playWrong();
      triggerHaptic([80, 50, 80]);
    }

    const answerRecord: QuizAnswer = {
      questionId: currentQ.id,
      selectedOptionIndex: idx >= 0 ? idx : null,
      isCorrect,
      timeSpentSec: 30 - timerSeconds,
    };

    setAnswers((prev) => [...prev, answerRecord]);
  };

  const handle5050Lifeline = () => {
    if (hasUsed5050 || isAnswered) return;

    // Pick 2 wrong indices to hide
    const wrongIndices = [0, 1, 2, 3].filter((i) => i !== currentQ.correctIndex);
    // Shuffle and pick 2
    const shuffled = wrongIndices.sort(() => 0.5 - Math.random());
    setHiddenOptions(shuffled.slice(0, 2));
    setHasUsed5050(true);
    soundFX.playRewardCoin();
    triggerHaptic(40);
  };

  const handleNext = () => {
    soundFX.playTap();
    if (currentIndex + 1 < questions.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      // Finished all 10 questions!
      const totalCorrect = answers.filter((a) => a.isCorrect).length + (selectedOption === currentQ.correctIndex ? 0 : 0);
      const wrongCount = answers.filter((a) => !a.isCorrect && a.selectedOptionIndex !== null).length;
      const skippedCount = questions.length - totalCorrect - wrongCount;
      const elapsedSeconds = Math.round((Date.now() - startTime) / 1000);

      const result: QuizSessionResult = {
        id: `session_${Date.now()}`,
        date: new Date().toISOString(),
        categoryTitle,
        categoryId,
        totalQuestions: questions.length,
        correctCount: totalCorrect,
        wrongCount,
        skippedCount,
        totalScore,
        maxScore: questions.length * 10,
        percentage: Math.round((totalCorrect / questions.length) * 100),
        timeTakenSec: elapsedSeconds,
        answers,
      };

      onFinishQuiz(result);
    }
  };

  const progressPercent = Math.round(((currentIndex + 1) / questions.length) * 100);

  return (
    <div className="flex-1 flex flex-col bg-slate-900 text-slate-100 overflow-y-auto">
      {/* Top Header Bar */}
      <div className="sticky top-0 z-20 bg-slate-950/90 backdrop-blur-md px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (window.confirm('क्या आप सचमुच क्विज छोड़ना चाहते हैं? आपकी प्रगति सुरक्षित नहीं होगी।')) {
                onExit();
              }
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xs font-bold text-slate-200 truncate max-w-[150px]">
              {categoryTitle}
            </h2>
            <div className="text-[10px] text-amber-400 font-medium">
              प्रश्न {currentIndex + 1} / {questions.length}
            </div>
          </div>
        </div>

        {/* Score & Controls */}
        <div className="flex items-center gap-2">
          <div className="px-2.5 py-1 bg-amber-500/15 border border-amber-500/30 rounded-lg text-amber-400 font-bold text-xs font-mono flex items-center gap-1">
            <span>स्कोर:</span>
            <span>{totalScore} अंक</span>
          </div>

          <button
            onClick={onToggleSound}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 transition-colors"
            title={soundEnabled ? 'ध्वनि बंद करें' : 'ध्वनि चालू करें'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* Progress Bar & Timer */}
      <div className="w-full bg-slate-800 h-1.5">
        <div
          className="bg-gradient-to-r from-amber-500 to-orange-500 h-full transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="px-4 py-2 flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/60 bg-slate-950/40">
        <div className="flex items-center gap-1.5">
          <Clock className={`w-3.5 h-3.5 ${timerSeconds <= 5 ? 'text-red-400 animate-pulse' : 'text-amber-400'}`} />
          <span className={`font-mono font-semibold ${timerSeconds <= 5 ? 'text-red-400' : 'text-slate-300'}`}>
            {timerSeconds} सेकंड
          </span>
          <button
            onClick={() => setTimerActive(!timerActive)}
            className="text-[10px] text-slate-500 hover:text-slate-300 underline ml-1"
          >
            {timerActive ? 'रोकें' : 'शुरू'}
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Lifeline 50:50 */}
          <button
            onClick={() => {
              if (hasUsed5050) return;
              // If not used, can trigger directly or via Rewarded ad
              handle5050Lifeline();
            }}
            disabled={hasUsed5050 || isAnswered}
            className={`px-2 py-0.5 rounded text-[11px] font-semibold border flex items-center gap-1 transition-all ${
              hasUsed5050
                ? 'bg-slate-800/50 text-slate-500 border-slate-800 cursor-not-allowed'
                : 'bg-indigo-950/60 text-indigo-300 border-indigo-700/60 hover:bg-indigo-900 active:scale-95'
            }`}
          >
            <Sparkles className="w-3 h-3 text-indigo-400" />
            <span>50:50 लाइफलाइन</span>
          </button>
        </div>
      </div>

      {/* Question Card Area */}
      <div className="p-4 flex-1 flex flex-col max-w-lg mx-auto w-full">
        {/* Difficulty badge & Points */}
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-medium text-slate-400">
            कठिनाई: <span className="text-amber-300">{currentQ.difficulty || 'मध्यम'}</span>
          </span>
          <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            +10 अंक
          </span>
        </div>

        {/* Question Text */}
        <div className="bg-slate-800/80 rounded-2xl p-4 border border-slate-700/80 shadow-md mb-4">
          <h3 className="text-base sm:text-lg font-bold text-slate-100 leading-relaxed">
            {currentQ.question}
          </h3>
        </div>

        {/* 4 Multiple Choice Options */}
        <div className="space-y-2.5 mb-4">
          {currentQ.options.map((opt, idx) => {
            const isHidden = hiddenOptions.includes(idx);
            if (isHidden) {
              return (
                <div
                  key={idx}
                  className="w-full min-h-[50px] p-3 rounded-xl border border-slate-800/40 bg-slate-950/30 text-slate-600 text-xs flex items-center justify-center line-through italic"
                >
                  50:50 द्वारा हटाया गया विकल्प
                </div>
              );
            }

            let optStyle = 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700/80';
            let iconElement = null;

            if (isAnswered) {
              if (idx === currentQ.correctIndex) {
                // Correct option
                optStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/30';
                iconElement = <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />;
              } else if (idx === selectedOption) {
                // Wrong option picked by user
                optStyle = 'bg-rose-950/80 border-rose-500 text-rose-200 ring-2 ring-rose-500/30';
                iconElement = <XCircle className="w-5 h-5 text-rose-400 shrink-0" />;
              } else {
                optStyle = 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-60';
              }
            }

            return (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={() => handleSelectOption(idx)}
                className={`w-full min-h-[52px] p-3 rounded-xl border text-left text-sm font-medium transition-all duration-150 flex items-center justify-between gap-3 active:scale-[0.99] shadow-sm ${optStyle}`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="font-bold text-amber-400 shrink-0 text-xs">
                    {optionLabels[idx]}
                  </span>
                  <span className="leading-snug">{opt}</span>
                </div>
                {iconElement}
              </button>
            );
          })}
        </div>

        {/* Explanation Card */}
        {isAnswered && (
          <div className="bg-slate-800/90 rounded-xl p-3.5 border border-amber-500/30 mb-4 animate-in fade-in duration-200">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                विस्तृत व्याख्या एवं तथ्य
              </span>
              <span className={`text-[11px] font-bold ${selectedOption === currentQ.correctIndex ? 'text-emerald-400' : 'text-rose-400'}`}>
                {selectedOption === currentQ.correctIndex ? 'सही उत्तर (+10)' : 'गलत उत्तर (0)'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {currentQ.explanation}
            </p>
          </div>
        )}

        {/* Spacer */}
        <div className="flex-1" />

        {/* Bottom CTA Button */}
        {isAnswered && (
          <button
            onClick={handleNext}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-orange-950/30 active:scale-[0.98] flex items-center justify-center gap-2"
          >
            <span>{currentIndex + 1 < questions.length ? 'अगला प्रश्न' : 'क्विज परिणाम देखें'}</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
};
