/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, UserCheck, ShieldCheck } from 'lucide-react';
import { UserProfile } from '../types';
import { soundFX } from '../utils/audio';

interface LoginModalProps {
  isOpen: boolean;
  currentUser: UserProfile;
  onClose: () => void;
  onLoginSuccess: (user: UserProfile) => void;
}

const AVATARS = ['👨‍🎓', '👩‍🎓', '👨‍🏫', '👩‍🏫', '🧑‍💻', '👨‍💼', '👩‍💼', '🇮🇳'];

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  currentUser,
  onClose,
  onLoginSuccess,
}) => {
  const [name, setName] = useState(currentUser.name || 'अभ्यर्थी विद्यार्थी');
  const [emailOrPhone, setEmailOrPhone] = useState(currentUser.emailOrPhone || '');
  const [state, setState] = useState(currentUser.state || 'उत्तर प्रदेश');
  const [targetExam, setTargetExam] = useState(currentUser.targetExam || 'UPSC / SSC / State PCS');
  const [selectedAvatar, setSelectedAvatar] = useState(currentUser.avatar || '👨‍🎓');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundFX.playTap();
    const updated: UserProfile = {
      ...currentUser,
      name: name.trim() || 'प्रतियोगी छात्र',
      emailOrPhone: emailOrPhone.trim() || 'student@gkquiz.in',
      state: state.trim() || 'भारत',
      targetExam: targetExam.trim() || 'प्रतियोगी परीक्षा',
      avatar: selectedAvatar,
      isLoggedIn: true,
    };
    onLoginSuccess(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl text-slate-100 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <UserCheck className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-sm font-bold text-white">
                छात्र लॉगिन एवं प्रोफ़ाइल
              </h2>
              <p className="text-[11px] text-slate-400">
                दैनिक स्कोर और रैंकिंग सुरक्षित रखें
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
          {/* Avatar selector */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1.5">
              अपना अवतार (Profile Icon) चुनें:
            </label>
            <div className="flex gap-2 justify-center py-1 bg-slate-950/60 rounded-xl p-2 border border-slate-800">
              {AVATARS.map((av) => (
                <button
                  key={av}
                  type="button"
                  onClick={() => setSelectedAvatar(av)}
                  className={`text-2xl p-1 rounded-xl transition-transform ${
                    selectedAvatar === av
                      ? 'bg-amber-500/25 border-2 border-amber-500 scale-110'
                      : 'hover:scale-105 opacity-70 hover:opacity-100'
                  }`}
                >
                  {av}
                </button>
              ))}
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              पूरा नाम:
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="उदा. राहुल कुमार"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* Mobile or Email */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1">
              मोबाइल नंबर / ईमेल (वैकल्पिक):
            </label>
            <input
              type="text"
              value={emailOrPhone}
              onChange={(e) => setEmailOrPhone(e.target.value)}
              placeholder="उदा. 9876543210 या email@example.com"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          {/* State & Target Exam */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                राज्य:
              </label>
              <input
                type="text"
                value={state}
                onChange={(e) => setState(e.target.value)}
                placeholder="उदा. उत्तर प्रदेश, बिहार"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-300 mb-1">
                लक्ष्य परीक्षा:
              </label>
              <input
                type="text"
                value={targetExam}
                onChange={(e) => setTargetExam(e.target.value)}
                placeholder="उदा. UPSC, SSC"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          <div className="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/60 flex items-center gap-2 text-[11px] text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>आपकी प्रगति आपके ब्राउज़र में सुरक्षित रहेगी।</span>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-colors"
          >
            सहेजें एवं क्विज खेलें
          </button>
        </form>
      </div>
    </div>
  );
};
