/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DailyQuizCard } from './DailyQuizCard';
import { CATEGORIES } from '../data/categories';
import { CategoryId, UserProfile, LeaderboardEntry } from '../types';
import { Landmark, Atom, Trophy, Globe2, Newspaper, Flame, Sparkles, ChevronRight, Lightbulb, Volume2, VolumeX, Shield, Award } from 'lucide-react';
import { soundFX } from '../utils/audio';

interface HomeScreenProps {
  user: UserProfile;
  leaderboardTop: LeaderboardEntry[];
  onStartDailyQuiz: () => void;
  onSelectCategory: (catId: CategoryId) => void;
  onNavigateToCategories: () => void;
  onNavigateToLeaderboard: () => void;
  onNavigateToProfile: () => void;
  onOpenAdMobPolicy: () => void;
  onOpenAdmin: () => void;
  onToggleSound: () => void;
}

const GK_FACTS = [
  {
    topic: 'चंद्रयान-3 व अंतरिक्ष',
    fact: 'भारत चंद्रमा के दक्षिणी ध्रुव पर अंतरिक्ष यान उतारने वाला विश्व का पहला देश बना था। इस स्थान का नाम ' + '"' + 'शिव शक्ति बिंदु' + '"' + ' रखा गया है।',
  },
  {
    topic: 'भारतीय संविधान',
    fact: 'मूल भारतीय संविधान को प्रेम बिहारी नारायण रायजादा ने अपने हाथों से इटैलिक सुलेख में लिखा था। इसे तैयार होने में 2 वर्ष 11 माह 18 दिन लगे थे।',
  },
  {
    topic: 'भूगोल एवं नदियां',
    fact: 'माजुली द्वीप (असम) विश्व का सबसे बड़ा नदी द्वीप है, जो ब्रह्मपुत्र नदी के मध्य स्थित है।',
  },
  {
    topic: 'विज्ञान एवं खोज',
    fact: 'मानव शरीर में सबसे छोटी हड्डी कान में पाई जाती है जिसे ' + '"' + 'स्टेप्स' + '"' + ' (Stapes) कहा जाता है।',
  },
  {
    topic: 'ओलंपिक खेल',
    fact: 'नीरज चोपड़ा ओलंपिक में एथलेटिक्स स्पर्धा में भारत के लिए स्वर्ण पदक जीतने वाले स्वतंत्र भारत के पहले ट्रैक एंड फील्ड एथलीट हैं।',
  },
];

export const HomeScreen: React.FC<HomeScreenProps> = ({
  user,
  leaderboardTop,
  onStartDailyQuiz,
  onSelectCategory,
  onNavigateToCategories,
  onNavigateToLeaderboard,
  onNavigateToProfile,
  onOpenAdMobPolicy,
  onOpenAdmin,
  onToggleSound,
}) => {
  const [factIndex, setFactIndex] = useState(0);

  const getCatIcon = (iconName: string) => {
    switch (iconName) {
      case 'Landmark':
        return Landmark;
      case 'Atom':
        return Atom;
      case 'Trophy':
        return Trophy;
      case 'Globe2':
        return Globe2;
      case 'Newspaper':
        return Newspaper;
      default:
        return Landmark;
    }
  };

  const handleNextFact = () => {
    soundFX.playTap();
    setFactIndex((prev) => (prev + 1) % GK_FACTS.length);
  };

  const currentFact = GK_FACTS[factIndex];

  return (
    <div className="flex-1 flex flex-col bg-slate-900 text-slate-100 overflow-y-auto p-4 max-w-lg mx-auto w-full space-y-4">
      {/* Top App Branding Bar */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-2.5">
          <img
            src="/src/assets/images/daily_gk_app_icon_1793463734432.jpg"
            alt="Daily GK Quiz App Icon"
            referrerPolicy="no-referrer"
            className="w-10 h-10 rounded-xl shadow-md border border-amber-500/30 object-cover"
          />
          <div>
            <h1 className="text-base font-extrabold text-white leading-tight">
              Daily GK Quiz
            </h1>
            <p className="text-[11px] text-amber-400 font-semibold tracking-wide">
              दैनिक सामान्य ज्ञान – हिंदी
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700/60"
            title={user.soundEnabled ? 'ध्वनि बंद करें' : 'ध्वनि चालू करें'}
          >
            {user.soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* User Streak Avatar Trigger */}
          <button
            onClick={() => {
              soundFX.playTap();
              onNavigateToProfile();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700/60 text-xs text-slate-200 transition-all active:scale-95"
          >
            <span className="text-base">{user.avatar}</span>
            <div className="flex items-center text-orange-400 font-bold font-mono text-[11px]">
              <Flame className="w-3 h-3 fill-orange-400" />
              <span>{user.currentStreakDays}d</span>
            </div>
          </button>
        </div>
      </div>

      {/* Hero Visual Card */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-700/80 shadow-lg">
        <img
          src="/src/assets/images/daily_quiz_hero_banner_1793463734467.jpg"
          alt="Daily GK Quiz Banner"
          referrerPolicy="no-referrer"
          className="w-full h-36 object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-3.5">
          <div className="w-full flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300">
                दैनिक ज्ञान अभ्यास
              </span>
              <h2 className="text-sm font-bold text-white">
                हर दिन 10 प्रश्न हल करें और परीक्षा में आगे रहें
              </h2>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Today's 10 GK Challenge Card */}
      <DailyQuizCard
        onStartDailyQuiz={onStartDailyQuiz}
        streakDays={user.currentStreakDays}
      />

      {/* Categories Grid Header & List */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>विषयवार क्विज (5 श्रेणियां)</span>
          </h2>
          <button
            onClick={() => {
              soundFX.playTap();
              onNavigateToCategories();
            }}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-0.5 font-medium"
          >
            <span>सभी देखें</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {CATEGORIES.slice(0, 4).map((cat) => {
            const Icon = getCatIcon(cat.icon);
            return (
              <button
                key={cat.id}
                onClick={() => {
                  soundFX.playTap();
                  onSelectCategory(cat.id);
                }}
                className="p-3 bg-slate-800/80 hover:bg-slate-750 border border-slate-700/70 rounded-2xl text-left transition-all active:scale-[0.98] shadow-sm flex flex-col justify-between group"
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`w-9 h-9 rounded-xl bg-gradient-to-br ${cat.gradient} flex items-center justify-center text-white shadow`}
                  >
                    <Icon className="w-4 h-4 stroke-[2.2]" />
                  </div>
                  <span className="text-[10px] text-amber-400/80 font-mono font-semibold">
                    10 Qs
                  </span>
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-100 group-hover:text-amber-400 transition-colors">
                    {cat.nameHindi}
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 truncate">
                    {cat.nameEnglish}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* 5th Category - Current Affairs full-width */}
        {CATEGORIES[4] && (
          <button
            onClick={() => {
              soundFX.playTap();
              onSelectCategory(CATEGORIES[4].id);
            }}
            className="w-full mt-2.5 p-3 bg-gradient-to-r from-purple-950/70 to-slate-800/90 hover:from-purple-900/70 border border-purple-700/40 rounded-2xl text-left transition-all active:scale-[0.98] shadow flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-700 flex items-center justify-center text-white shadow">
                <Newspaper className="w-4 h-4 stroke-[2.2]" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>{CATEGORIES[4].nameHindi}</span>
                  <span className="text-[10px] text-purple-300 bg-purple-500/20 px-1.5 py-0.2 rounded font-normal">
                    लेटेस्ट अपडेट
                  </span>
                </h3>
                <p className="text-[10px] text-slate-300">
                  राष्ट्रीय व अंतर्राष्ट्रीय नवीनतम घटनाक्रम (10 प्रश्न)
                </p>
              </div>
            </div>

            <ChevronRight className="w-4 h-4 text-purple-400" />
          </button>
        )}
      </div>

      {/* GK Fact of the Day (ज्ञान दर्पण) */}
      <div className="bg-slate-800/70 rounded-2xl p-3.5 border border-amber-500/30 shadow-sm relative">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
            <Lightbulb className="w-4 h-4 text-amber-400" />
            <span>आज का ज्ञान (GK Fact)</span>
          </span>
          <button
            onClick={handleNextFact}
            className="text-[11px] text-amber-400 hover:text-amber-300 underline font-medium"
          >
            अगला तथ्य →
          </button>
        </div>

        <div className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider mb-1">
          {currentFact.topic}
        </div>
        <p className="text-xs text-slate-200 leading-relaxed">
          {currentFact.fact}
        </p>
      </div>

      {/* Leaderboard Mini Snippet */}
      <div className="bg-slate-800/60 rounded-2xl p-3.5 border border-slate-700/70">
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-amber-400" />
            <span>दैनिक टॉप 3 छात्र</span>
          </span>
          <button
            onClick={() => {
              soundFX.playTap();
              onNavigateToLeaderboard();
            }}
            className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-0.5 font-medium"
          >
            <span>लीडरबोर्ड</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          {leaderboardTop.slice(0, 3).map((item, idx) => (
            <div
              key={item.id}
              className="bg-slate-900/60 p-2 rounded-xl border border-slate-800 flex flex-col items-center"
            >
              <div className="text-xl mb-0.5">{item.avatar}</div>
              <div className="text-[11px] font-bold text-slate-100 truncate w-full">
                {item.name}
              </div>
              <div className="text-[10px] text-amber-400 font-mono font-bold mt-0.5">
                {item.score} अंक
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Admin & Ad Policy link */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 pb-4">
        <button
          onClick={onOpenAdMobPolicy}
          className="hover:text-amber-400 transition-colors flex items-center gap-1"
        >
          <span>AdMob विज्ञापन नीति</span>
        </button>

        <button
          onClick={onOpenAdmin}
          className="hover:text-purple-400 transition-colors flex items-center gap-1"
        >
          <Shield className="w-3.5 h-3.5 text-purple-400" />
          <span>एडमिन प्रश्न पैनल</span>
        </button>
      </div>
    </div>
  );
};
