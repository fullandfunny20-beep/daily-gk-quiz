/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Home, Layers, Trophy, User } from 'lucide-react';
import { soundFX, triggerHaptic } from '../utils/audio';

export type NavTabId = 'home' | 'categories' | 'leaderboard' | 'profile';

interface AndroidNavBarProps {
  activeTab: NavTabId;
  onTabChange: (tab: NavTabId) => void;
}

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'home' as NavTabId, label: 'होम', icon: Home },
    { id: 'categories' as NavTabId, label: 'श्रेणियां', icon: Layers },
    { id: 'leaderboard' as NavTabId, label: 'लीडरबोर्ड', icon: Trophy },
    { id: 'profile' as NavTabId, label: 'प्रोफ़ाइल', icon: User },
  ];

  const handleSelect = (tab: NavTabId) => {
    soundFX.playTap();
    triggerHaptic(25);
    onTabChange(tab);
  };

  return (
    <nav className="w-full bg-slate-950/95 backdrop-blur-lg border-t border-slate-800/80 px-2 py-1 select-none shrink-0 z-30">
      <div className="grid grid-cols-4 items-center max-w-md mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleSelect(tab.id)}
              className={`min-h-[52px] flex flex-col items-center justify-center transition-all duration-150 active:scale-95 relative ${
                isActive ? 'text-amber-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div
                className={`flex items-center justify-center px-4 py-1 rounded-full transition-all duration-200 ${
                  isActive ? 'bg-amber-500/15 text-amber-400 scale-105' : ''
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.4]' : 'stroke-[1.8]'}`} />
              </div>
              <span className="text-[11px] tracking-tight mt-0.5">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
