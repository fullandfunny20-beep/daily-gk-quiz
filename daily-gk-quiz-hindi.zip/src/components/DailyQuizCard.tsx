/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Calendar, ArrowRight, Flame } from 'lucide-react';
import { soundFX } from '../utils/audio';

interface DailyQuizCardProps {
  onStartDailyQuiz: () => void;
  streakDays: number;
}

export const DailyQuizCard: React.FC<DailyQuizCardProps> = ({ onStartDailyQuiz, streakDays }) => {
  const todayHindi = new Intl.DateTimeFormat('hi-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  const handleStart = () => {
    soundFX.playTap();
    onStartDailyQuiz();
  };

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-amber-600 via-orange-600 to-amber-700 text-white shadow-xl shadow-orange-950/20 p-4 border border-amber-400/30">
      {/* Decorative background graphics */}
      <div className="absolute -right-8 -top-8 w-36 h-36 bg-white/10 rounded-full blur-xl pointer-events-none" />
      <div className="absolute -left-6 -bottom-6 w-32 h-32 bg-amber-400/10 rounded-full blur-lg pointer-events-none" />

      {/* Header Info */}
      <div className="relative z-10 flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5 text-amber-100 text-xs font-medium">
          <Calendar className="w-3.5 h-3.5" />
          <span>{todayHindi}</span>
        </div>

        <div className="flex items-center gap-1 bg-black/25 backdrop-blur-md px-2.5 py-1 rounded-full text-xs font-bold text-amber-200 border border-white/15">
          <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>{streakDays} दिन स्ट्रीक</span>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 mb-3">
        <div className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-amber-200 bg-amber-900/40 px-2 py-0.5 rounded-md mb-1.5 border border-amber-300/30">
          <Sparkles className="w-3 h-3" />
          <span>दैनिक 10 GK चैलेंज</span>
        </div>
        <h2 className="text-xl font-extrabold text-white leading-tight">
          आज का विशेष सामान्य ज्ञान क्विज
        </h2>
        <p className="text-xs text-amber-100 mt-1 line-clamp-2">
          इतिहास, विज्ञान, खेलकूद, भूगोल व समसामयिकी के 10 चुनिंदा प्रश्न। हर सही उत्तर पर पाएं +10 अंक!
        </p>
      </div>

      {/* Meta indicators */}
      <div className="relative z-10 grid grid-cols-3 gap-2 bg-black/25 rounded-xl p-2.5 mb-3 border border-white/10 text-center">
        <div>
          <div className="text-[10px] text-amber-200">कुल प्रश्न</div>
          <div className="text-sm font-bold font-mono text-white">10 प्रश्न</div>
        </div>
        <div>
          <div className="text-[10px] text-amber-200">अधिकतम अंक</div>
          <div className="text-sm font-bold font-mono text-amber-300">100 अंक</div>
        </div>
        <div>
          <div className="text-[10px] text-amber-200">समय</div>
          <div className="text-sm font-bold font-mono text-white">लचीला</div>
        </div>
      </div>

      {/* Start Button */}
      <button
        onClick={handleStart}
        className="relative z-10 w-full py-3 px-4 bg-slate-950 hover:bg-slate-900 text-amber-400 font-bold text-sm rounded-xl transition-all duration-150 shadow-lg active:scale-[0.98] flex items-center justify-center gap-2 border border-amber-400/40"
      >
        <span>क्विज शुरू करें</span>
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  );
};
