/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { X, Volume2, ShieldCheck } from 'lucide-react';
import { trackAdMobImpression } from '../utils/storage';

interface AdMobInterstitialProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
}

export const AdMobInterstitial: React.FC<AdMobInterstitialProps> = ({
  isOpen,
  onClose,
  title = 'दैनिक क्विज प्रायोजक संदेश',
}) => {
  const [countdown, setCountdown] = useState(5);
  const [canSkip, setCanSkip] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setCountdown(5);
      setCanSkip(false);
      trackAdMobImpression('interstitial');

      const interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setCanSkip(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-700/80 rounded-2xl overflow-hidden shadow-2xl text-slate-100 flex flex-col">
        {/* AdMob Top Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/80 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase border border-amber-500/30">
              AdMob Interstitial Ad
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              Test Unit
            </span>
          </div>

          <div>
            {canSkip ? (
              <button
                onClick={onClose}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700 active:scale-95"
              >
                <span>आगे बढ़ें</span>
                <X className="w-3.5 h-3.5" />
              </button>
            ) : (
              <div className="text-[11px] text-slate-400 font-mono">
                स्किप करें {countdown}s में
              </div>
            )}
          </div>
        </div>

        {/* Ad Body Content */}
        <div className="p-5 flex-1 flex flex-col items-center text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20 mb-4 text-3xl">
            🏆
          </div>

          <h3 className="text-lg font-bold text-white mb-1">
            {title}
          </h3>
          <p className="text-xs text-amber-400 font-medium mb-3">
            Google AdMob विज्ञापन नेटवर्क द्वारा संचालित
          </p>

          <div className="w-full bg-slate-800/60 rounded-xl p-3 border border-slate-700/50 mb-4 text-left">
            <div className="flex items-center gap-2 mb-1.5 text-xs font-semibold text-slate-200">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Google Play नीति अनुरूप विज्ञापन</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              यह विज्ञापन ऐप को उपयोगकर्ताओं के लिए 100% निःशुल्क और नियमित अपडेट रखने में सहायता करता है। ऐप निर्माता वैध विज्ञापनों से राजस्व प्राप्त करते हैं।
            </p>
          </div>

          <div className="w-full bg-slate-800/40 rounded-lg p-2.5 text-left mb-4">
            <div className="text-[10px] text-slate-400 font-mono mb-1">
              Ad Unit: ca-app-pub-3940256099942544/1033173712
            </div>
            <div className="text-xs font-medium text-slate-200">
              सरकारी नौकरी 2026 GK कम्प्लीट बुक्स एवं ऑनलाइन टेस्ट
            </div>
          </div>

          {/* Action button */}
          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center gap-2"
          >
            <Volume2 className="w-4 h-4" />
            <span>{canSkip ? 'क्विज परिणाम पर जाएं' : `कृपया प्रतीक्षा करें (${countdown}s)`}</span>
          </button>
        </div>

        {/* Footer disclosure */}
        <div className="px-4 py-2 bg-slate-950 text-[10px] text-slate-400 text-center border-t border-slate-800/80">
          बिना किसी गलत वादे के वैध विज्ञापन प्रणाली (AdMob Compliant)
        </div>
      </div>
    </div>
  );
};
