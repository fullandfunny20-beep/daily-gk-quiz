/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Play, CheckCircle2, X } from 'lucide-react';
import { trackAdMobImpression } from '../utils/storage';
import { soundFX } from '../utils/audio';

interface AdMobRewardedProps {
  isOpen: boolean;
  rewardType: '50_50_lifeline' | 'hint' | 'bonus_score';
  onClose: () => void;
  onRewardGranted: () => void;
}

export const AdMobRewarded: React.FC<AdMobRewardedProps> = ({
  isOpen,
  rewardType,
  onClose,
  onRewardGranted,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(5);
  const [rewardGranted, setRewardGranted] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsPlaying(false);
      setSecondsRemaining(5);
      setRewardGranted(false);
    }
  }, [isOpen]);

  const startWatchingAd = () => {
    setIsPlaying(true);
    trackAdMobImpression('rewarded');

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setRewardGranted(true);
          soundFX.playRewardCoin();
          onRewardGranted();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  if (!isOpen) return null;

  const rewardTitles = {
    '50_50_lifeline': '50:50 लाइफलाइन (2 गलत विकल्प हटाएं)',
    'hint': 'प्रश्न का संकेत (Hint) अनलॉक करें',
    'bonus_score': '+10 अतिरिक्त अभ्यास बोनस अंक',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 border border-amber-500/30 rounded-2xl overflow-hidden shadow-2xl text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-1.5">
            <span className="bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded text-[10px] uppercase border border-amber-500/30">
              AdMob Rewarded Video
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Test Unit
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col items-center text-center">
          {!isPlaying && !rewardGranted ? (
            <>
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 mb-3 shadow-inner">
                <Play className="w-7 h-7 fill-amber-400" />
              </div>

              <h3 className="text-base font-bold text-white mb-1">
                पुरस्कृत वीडियो विज्ञापन (Rewarded Ad)
              </h3>
              <p className="text-xs text-amber-300 font-medium mb-3">
                {rewardTitles[rewardType]}
              </p>

              <div className="w-full bg-slate-800/60 rounded-xl p-3 border border-slate-700/60 mb-4 text-left">
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  एक छोटा 5-सेकंड का प्रायोजक विज्ञापन देखकर आप इन-गेम लाइफलाइन प्राप्त कर सकते हैं।
                </p>
                <p className="text-[10px] text-slate-400 mt-2 font-mono">
                  Ad Unit: ca-app-pub-3940256099942544/5224354917
                </p>
              </div>

              <div className="flex gap-2 w-full">
                <button
                  onClick={onClose}
                  className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
                >
                  अभी नहीं
                </button>
                <button
                  onClick={startWatchingAd}
                  className="flex-1 py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>वीडियो देखें</span>
                </button>
              </div>
            </>
          ) : isPlaying && !rewardGranted ? (
            <div className="w-full py-6 flex flex-col items-center">
              <div className="w-20 h-20 rounded-full border-4 border-amber-500 border-t-transparent animate-spin flex items-center justify-center mb-4">
                <span className="text-xl font-bold font-mono text-amber-400">{secondsRemaining}s</span>
              </div>
              <h4 className="text-sm font-semibold text-white mb-1">
                प्रायोजक वीडियो चल रहा है...
              </h4>
              <p className="text-xs text-slate-400">
                कृपया {secondsRemaining} सेकंड तक प्रतीक्षा करें
              </p>
              <div className="mt-4 px-3 py-1.5 bg-slate-800/80 rounded-lg text-[11px] text-amber-300 border border-slate-700">
                Google AdMob Test Creative
              </div>
            </div>
          ) : (
            <div className="w-full py-4 flex flex-col items-center animate-in zoom-in-95 duration-200">
              <CheckCircle2 className="w-14 h-14 text-emerald-400 mb-2" />
              <h3 className="text-base font-bold text-white mb-1">
                बधाई हो! पुरस्कार अनलॉक हुआ
              </h3>
              <p className="text-xs text-emerald-400 font-medium mb-4">
                {rewardTitles[rewardType]} आपके क्विज में सक्रिय हो गया है।
              </p>
              <button
                onClick={onClose}
                className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-colors"
              >
                क्विज जारी रखें
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2 bg-slate-950 text-[10px] text-slate-400 text-center border-t border-slate-800">
          Google AdMob विज्ञापन नीति अनुसार (कोई फर्जी कमाई का वादा नहीं)
        </div>
      </div>
    </div>
  );
};
