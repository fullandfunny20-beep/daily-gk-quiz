/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AndroidFrame } from './components/AndroidFrame';
import { AndroidNavBar, NavTabId } from './components/AndroidNavBar';
import { HomeScreen } from './components/HomeScreen';
import { CategoriesScreen } from './components/CategoriesScreen';
import { LeaderboardScreen } from './components/LeaderboardScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { QuizPlayScreen } from './components/QuizPlayScreen';
import { QuizResultScreen } from './components/QuizResultScreen';
import { AdMobBanner } from './components/AdMobBanner';
import { AdMobInterstitial } from './components/AdMobInterstitial';
import { AdMobRewarded } from './components/AdMobRewarded';
import { AdMobPolicyModal } from './components/AdMobPolicyModal';
import { AdminPanelModal } from './components/AdminPanelModal';
import { LoginModal } from './components/LoginModal';

import { Question, CategoryId, UserProfile, LeaderboardEntry, QuizSessionResult } from './types';
import { CATEGORIES } from './data/categories';
import {
  getStoredQuestions,
  saveQuestions,
  getStoredUserProfile,
  saveUserProfile,
  getStoredLeaderboard,
  saveQuizSessionResult,
  updateLeaderboardWithUser,
} from './utils/storage';
import { soundFX } from './utils/audio';

export default function App() {
  // App navigation state
  const [activeTab, setActiveTab] = useState<NavTabId>('home');
  const [appMode, setAppMode] = useState<'normal' | 'playing' | 'result'>('normal');
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);

  // Core Data state
  const [questions, setQuestions] = useState<Question[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>(getStoredUserProfile());
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);

  // Current Quiz session
  const [activeQuizQuestions, setActiveQuizQuestions] = useState<Question[]>([]);
  const [activeQuizTitle, setActiveQuizTitle] = useState('दैनिक 10 GK क्विज');
  const [activeQuizCategoryId, setActiveQuizCategoryId] = useState<CategoryId | 'daily'>('daily');
  const [lastQuizResult, setLastQuizResult] = useState<QuizSessionResult | null>(null);

  // Modals state
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdMobPolicyOpen, setIsAdMobPolicyOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);

  // AdMob Ad Triggers
  const [showInterstitial, setShowInterstitial] = useState(false);
  const [showRewarded, setShowRewarded] = useState(false);
  const [rewardType, setRewardType] = useState<'50_50_lifeline'>('50_50_lifeline');

  // Initialize data on mount
  useEffect(() => {
    const loadedQuestions = getStoredQuestions();
    setQuestions(loadedQuestions);

    const loadedProfile = getStoredUserProfile();
    setUserProfile(loadedProfile);
    soundFX.setSoundEnabled(loadedProfile.soundEnabled);

    updateLeaderboardWithUser(loadedProfile);
    setLeaderboard(getStoredLeaderboard());
  }, []);

  // Update questions handler
  const handleUpdateQuestions = (updated: Question[]) => {
    setQuestions(updated);
    saveQuestions(updated);
  };

  // Update user profile handler
  const handleUpdateUser = (updated: UserProfile) => {
    setUserProfile(updated);
    saveUserProfile(updated);
    updateLeaderboardWithUser(updated);
    setLeaderboard(getStoredLeaderboard());
  };

  // Sound toggle
  const handleToggleSound = () => {
    const nextVal = !userProfile.soundEnabled;
    soundFX.setSoundEnabled(nextVal);
    if (nextVal) soundFX.playTap();
    handleUpdateUser({ ...userProfile, soundEnabled: nextVal });
  };

  // Prepare and start Daily 10 Quiz
  const handleStartDailyQuiz = () => {
    soundFX.playTap();
    // Daily mix: pick 2 from each category (or fallback to any 10)
    let selected: Question[] = [];

    // Prioritize 2 questions from each category for well-rounded 10 questions
    CATEGORIES.forEach((c) => {
      const catQs = questions.filter((q) => q.category === c.id);
      const shuffled = [...catQs].sort(() => 0.5 - Math.random());
      selected.push(...shuffled.slice(0, 2));
    });

    if (selected.length < 10) {
      const remaining = questions.filter((q) => !selected.includes(q));
      selected.push(...remaining.slice(0, 10 - selected.length));
    }

    selected = selected.slice(0, 10);

    setActiveQuizQuestions(selected);
    setActiveQuizTitle('दैनिक 10 GK चैलेंज');
    setActiveQuizCategoryId('daily');
    setAppMode('playing');
  };

  // Prepare and start Category Quiz
  const handleSelectCategory = (catId: CategoryId) => {
    soundFX.playTap();
    const catInfo = CATEGORIES.find((c) => c.id === catId);
    const catQs = questions.filter((q) => q.category === catId);
    const shuffled = [...catQs].sort(() => 0.5 - Math.random());
    const selected = shuffled.slice(0, 10);

    setActiveQuizQuestions(selected.length > 0 ? selected : questions.slice(0, 10));
    setActiveQuizTitle(`${catInfo?.nameHindi || 'सामान्य ज्ञान'} क्विज (10 प्रश्न)`);
    setActiveQuizCategoryId(catId);
    setAppMode('playing');
  };

  // When a quiz session finishes
  const handleFinishQuiz = (result: QuizSessionResult) => {
    // Save to storage and update profile
    saveQuizSessionResult(result);
    setLastQuizResult(result);

    // Refresh user profile & leaderboard
    const updatedUser = getStoredUserProfile();
    setUserProfile(updatedUser);
    setLeaderboard(getStoredLeaderboard());

    // Play fanfare
    soundFX.playFanfare();

    // Trigger AdMob Interstitial ad with a compliant 5-sec countdown
    setShowInterstitial(true);
    setAppMode('result');
  };

  return (
    <AndroidFrame
      isPhoneFrame={isPhoneFrame}
      onToggleFrame={() => setIsPhoneFrame(!isPhoneFrame)}
    >
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-900">
        {/* Main Body Switcher */}
        {appMode === 'playing' ? (
          <QuizPlayScreen
            questions={activeQuizQuestions}
            categoryTitle={activeQuizTitle}
            categoryId={activeQuizCategoryId}
            soundEnabled={userProfile.soundEnabled}
            onToggleSound={handleToggleSound}
            onExit={() => setAppMode('normal')}
            onFinishQuiz={handleFinishQuiz}
            onRequestRewardedAd={(type) => {
              setRewardType(type);
              setShowRewarded(true);
            }}
          />
        ) : appMode === 'result' && lastQuizResult ? (
          <QuizResultScreen
            result={lastQuizResult}
            questions={activeQuizQuestions}
            onPlayAgain={() => {
              if (activeQuizCategoryId === 'daily') {
                handleStartDailyQuiz();
              } else {
                handleSelectCategory(activeQuizCategoryId as CategoryId);
              }
            }}
            onGoHome={() => {
              setAppMode('normal');
              setActiveTab('home');
            }}
            onGoLeaderboard={() => {
              setAppMode('normal');
              setActiveTab('leaderboard');
            }}
          />
        ) : (
          <div className="flex-1 flex flex-col overflow-hidden">
            {activeTab === 'home' && (
              <HomeScreen
                user={userProfile}
                leaderboardTop={leaderboard}
                onStartDailyQuiz={handleStartDailyQuiz}
                onSelectCategory={handleSelectCategory}
                onNavigateToCategories={() => setActiveTab('categories')}
                onNavigateToLeaderboard={() => setActiveTab('leaderboard')}
                onNavigateToProfile={() => setActiveTab('profile')}
                onOpenAdMobPolicy={() => setIsAdMobPolicyOpen(true)}
                onOpenAdmin={() => setIsAdminOpen(true)}
                onToggleSound={handleToggleSound}
              />
            )}

            {activeTab === 'categories' && (
              <CategoriesScreen
                questions={questions}
                onSelectCategory={handleSelectCategory}
              />
            )}

            {activeTab === 'leaderboard' && (
              <LeaderboardScreen
                entries={leaderboard}
                currentUserId={userProfile.id}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileScreen
                user={userProfile}
                onUpdateUser={handleUpdateUser}
                onOpenAdmin={() => setIsAdminOpen(true)}
                onOpenAdMobPolicy={() => setIsAdMobPolicyOpen(true)}
                onOpenLoginModal={() => setIsLoginOpen(true)}
              />
            )}
          </div>
        )}

        {/* AdMob Banner - Visible on Normal & Result screens per Google AdMob Guidelines */}
        {appMode !== 'playing' && (
          <AdMobBanner
            position="bottom"
            onOpenPolicy={() => setIsAdMobPolicyOpen(true)}
          />
        )}

        {/* Bottom Navigation Bar - Only visible in normal browsing */}
        {appMode === 'normal' && (
          <AndroidNavBar
            activeTab={activeTab}
            onTabChange={(tab) => setActiveTab(tab)}
          />
        )}
      </div>

      {/* Full-Screen AdMob Interstitial Overlay */}
      <AdMobInterstitial
        isOpen={showInterstitial}
        onClose={() => setShowInterstitial(false)}
        title="क्विज संपन्न! प्रायोजक संदेश"
      />

      {/* Rewarded Video Ad Modal */}
      <AdMobRewarded
        isOpen={showRewarded}
        rewardType={rewardType}
        onClose={() => setShowRewarded(false)}
        onRewardGranted={() => {
          // Reward successfully granted
        }}
      />

      {/* AdMob & Google Play Policy Transparency Modal */}
      <AdMobPolicyModal
        isOpen={isAdMobPolicyOpen}
        onClose={() => setIsAdMobPolicyOpen(false)}
      />

      {/* Admin Panel Modal for Question Management */}
      <AdminPanelModal
        isOpen={isAdminOpen}
        questions={questions}
        onClose={() => setIsAdminOpen(false)}
        onUpdateQuestions={handleUpdateQuestions}
      />

      {/* User Login & Profile Modal */}
      <LoginModal
        isOpen={isLoginOpen}
        currentUser={userProfile}
        onClose={() => setIsLoginOpen(false)}
        onLoginSuccess={handleUpdateUser}
      />
    </AndroidFrame>
  );
}
