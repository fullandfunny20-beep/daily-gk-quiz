/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CategoryInfo } from '../types';

export const CATEGORIES: CategoryInfo[] = [
  {
    id: 'history',
    nameHindi: 'इतिहास',
    nameEnglish: 'History',
    icon: 'Landmark',
    description: 'प्राचीन, मध्यकालीन एवं आधुनिक भारत का गौरवशाली इतिहास',
    color: 'amber',
    gradient: 'from-amber-600 to-orange-700',
    totalQuestions: 12,
  },
  {
    id: 'science',
    nameHindi: 'विज्ञान',
    nameEnglish: 'Science',
    icon: 'Atom',
    description: 'भौतिकी, रसायन, जीव विज्ञान एवं आधुनिक अंतरिक्ष प्रौद्योगिकी',
    color: 'emerald',
    gradient: 'from-emerald-600 to-teal-700',
    totalQuestions: 12,
  },
  {
    id: 'sports',
    nameHindi: 'खेलकूद',
    nameEnglish: 'Sports',
    icon: 'Trophy',
    description: 'क्रिकेट, ओलंपिक, एशियाई खेल एवं राष्ट्रीय व अंतर्राष्ट्रीय स्पर्धाएं',
    color: 'blue',
    gradient: 'from-blue-600 to-indigo-700',
    totalQuestions: 12,
  },
  {
    id: 'geography',
    nameHindi: 'भूगोल',
    nameEnglish: 'Geography',
    icon: 'Globe2',
    description: 'भारत एवं विश्व की नदियां, पर्वत, अभयारण्य और जलवायु',
    color: 'teal',
    gradient: 'from-teal-600 to-cyan-700',
    totalQuestions: 12,
  },
  {
    id: 'current_affairs',
    nameHindi: 'समसामयिकी',
    nameEnglish: 'Current Affairs',
    icon: 'Newspaper',
    description: 'राष्ट्रीय व अंतर्राष्ट्रीय नवीनतम घटनाक्रम, प्रमुख योजनाएं व नियुक्तियां',
    color: 'purple',
    gradient: 'from-purple-600 to-violet-700',
    totalQuestions: 12,
  },
];
